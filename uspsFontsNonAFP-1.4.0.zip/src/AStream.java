import java.io.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;

/**
 *  Defines methods common to IStream classes such as
 *  PSStream, PCLStream, MetacodeStream, etc.
 *
 *@author     The Powell Group, TPG
 *@created    March 8, 2006
 */
abstract class AStream {

    private static USPS4CB usps = new USPS4CB();

    /**
     *  Gets the bar-code generated from Track and Route numbers collected
     *  and available in the Map parameter M
     *  It uses USPS4CB to load and call the USPS encoder c-routine.
     *  This c-routine is platform dependant; USPS4CB detects the OS and
     *  platform and loads the correspondig *.dll or *.so library
     *
     *@param  M  Map containing program wide parameters
     *@return    USPS4CB 65-characater encoded String
     */
    protected static String getBarCode(Map M) {
        String bc = M.get("barCode").toString();
        if (bc.length() == 65) {
            return bc;
        }
        usps.setTrack(M.get("track").toString());
        usps.setRoute(M.get("route").toString());
        bc = usps.getBarCode();
        return bc.substring(3);     // should do error checking as returned
                                    // in the first two characters; "00" ok.
    }

    /**
     *  Formats date and time as defined by String dateFormat
     *
     *@param  dateFormat  Formatting pattern using SimpleDateFormat
     *                    String definitions
     *@return             Formated date and time String
     */
    protected String todayFormated(String dateFormat) {
        java.util.Date currentDate = new java.util.Date();
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        return sdf.format(currentDate);
    }
}

