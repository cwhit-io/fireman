import java.io.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;

public class MetaCodeStream extends AStream implements IStream  {
    private FileOutputStream out = null;
    private InputStream       in = null;
    boolean             bfontSet = false;
    private                Map P = null;

    public MetaCodeStream( Map M ) {
        super();
        this.P = M;
    }

    public IStream close() {
        try { this.out.flush(); this.out.close(); }
        catch ( Exception e ) { e.printStackTrace(); }
        return this;
    }

    public void write( Map M ) {
        List X = (List) M.get( "text" );
        for( int i=0; i< X.size(); i++ ) this.addText( X.get(i).toString() );
        //this.addBar( M.get( "barCode" ).toString() );
        this.addBar( super.getBarCode( M ) );
    }

    public IStream add(String str) {
        byte buff[] = new byte[str.length()];
        for (int i=0, l=str.length(); i < l; i++) buff[i] = (byte)str.charAt(i);
        try { out.write(buff); }
        catch (Exception e) {
            e.printStackTrace();e.printStackTrace(System.out);
        }
        return this;
    }

    public IStream newPage() { this.add( "  1\f\n\r" );;  return this; }

    public IStream addText( String str ) {
        if( !bfontSet ) this.init();
        this.add( "  1" + str + "\n\r" );
        return this;
    }

    public IStream addBar( String str ) {
        String fn = this.P.get( "-fn" ).toString();
        String scale = fn.matches(".*[fF].*") ? "14.4" : "9.12";
        // add code to set 14.4 or 10.5 scaleing factor
        this.add( "  2" + str + "\n\r" );
        this.add( "  1\n\r" );
        return this;
    }

    private void init() {
        try {
            out = new FileOutputStream( new File( P.get( "-of" ).toString() ) );
            in  = new FileInputStream(  new File( P.get( "-font" ).toString() ) );
            //this.add( "$DJDE$ FILE =(,,L,D), END;\n\r" );
            //byte[] buf = new byte[2048];
            //int i = 0;
            //while((i=in.read(buf))!=-1) this.out.write(buf, 0, i);
            this.bfontSet = true;
            this.add( "   $DJDE$ JDL=C4BJSL,JDE=" + this.P.get( "-fn" ).toString() +",END;\n\r" );
            this.add( "  1\n\r" );
            //this.add( "$DJDE$ END;\n\r" );
            //this.add( "$DJDE$ FONTS=(POYTYA, " + this.P.get("-fn").toString() + "), END;\n\r" );
            //StringBuffer sb = new StringBuffer( super.todayFormated("yyyy.MMM.dd@kk:mm:ss") );
            //sb.append( " " ).append( this.P.get( "-fn" ).toString() );
            //this.addText( sb.toString() );
            //this.addText( " " );
        } catch (Exception e) { e.printStackTrace(); }
    }

}

