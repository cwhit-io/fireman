import java.util.Map;

/**
 *  Defines method signatures common to classes that implement 
 *  IStream
 *
 *@author     The Powell Group, TPG
 *@created    March 8, 2006
 */
public interface IStream {

    public void    write(Map M);
    public IStream close();
    public IStream addText(String str);
    public IStream addBar(String str);
    public IStream newPage();
}

