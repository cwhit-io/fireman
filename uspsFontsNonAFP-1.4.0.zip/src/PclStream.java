import java.io.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;

public class PclStream extends AStream implements IStream  {
    private FileOutputStream out = null;
    private InputStream       in = null;
    boolean             bfontSet = false;
    private                Map P = null;

    public PclStream( Map M ) {
        super();
        this.P = M;
    }

    public IStream close() {
        try { this.out.flush(); this.out.close(); }
        catch ( Exception e ) { e.printStackTrace(); }
        return this;
    }

    public void write( Map M ) {
        List X = (List) M.get( "text" );
        for( int i=0; i< X.size(); i++ ) this.addText( X.get(i).toString() );
        //this.addBar( M.get( "barCode" ).toString() );
        this.addBar( super.getBarCode( M ) );
    }

    public IStream addText( String str ) {
        if( !bfontSet ) this.init();
        this.add( str + "\n" );
        return this;
    }

    public IStream addBar( String str ) {
        String fn = this.P.get( "-fn" ).toString();
        String scale = fn.matches(".*[fF].*") ? "14.4" : "9.12";
        this.add( "\033(30000X" );              // select font
        this.add( "\033s" + scale + "V" );      // scale to 14.4 or 10.5
        this.add(  "\n" + str  );
        this.add( "\033(3@" );
        this.add( "\033(8U\033(s0p10v0b3T\n\n\n\n" );
        return this;
    }

    public IStream add(String str) {
        byte buff[] = new byte[str.length()];
        for (int i=0, l=str.length(); i < l; i++) buff[i] = (byte)str.charAt(i);
        try { out.write(buff); }
        catch (Exception e) {
            e.printStackTrace();e.printStackTrace(System.out);
        }
        return this;
    }

    public IStream newPage() {
        this.add( "\f" );
        this.add( "\033E" );
        return this;
    }

    private String orientation() {
        String fn = this.P.get( "-fn" ).toString().toUpperCase();
        StringBuffer sb = new StringBuffer( "\033&l" );
        sb.append( fn.endsWith( "P" ) ? "0" : fn.endsWith( "L" ) ? "1" :
                   fn.endsWith( "I" ) ? "2" : "3" ).append( "O" );
        return sb.toString();
    }

    private void init() {
        try {
            out = new FileOutputStream( new File( P.get( "-of" ).toString() ) );
            in  = new FileInputStream(  new File( P.get( "-font" ).toString() ) );
            this.add( "\033E" );            // reset
            this.add( this.orientation() );
            this.add( "\033*c30000D" );     // define 30000 id font
            byte[] buf = new byte[2048];
            int i = 0;
            while((i=in.read(buf))!=-1) this.out.write(buf, 0, i);
            this.bfontSet = true;
            this.add( "\033*c5F" );         // make defined font survive resets
            this.add( "\033(3@" );          // reset
            this.add( "\033&l0O" );         // portrait
            this.add( "\033&k2G" );         // convert "LF" to "CR+LF"
            this.add("\033(8U\033(s0p10v0b3T"); // courrer 10 points
            //StringBuffer sb = new StringBuffer( super.todayFormated("yyyy.MMM.dd@kk:mm:ss") );
            //sb.append( " " ).append( this.P.get( "-fn" ).toString() );
            //this.addText( sb.toString() );
            //this.addText( " " );
        } catch (Exception e) { e.printStackTrace(); }
    }

}

/****************************************************************************

<esc>(s#T   typeface selection (#= 3-Courier,4-Helvetica, 5-Times-Roman)
<esc>(s#H   pitch selection (#= usually 10 or 16.66 built-in)
<esc>(s#V   character height (#= Font Size in points)
<esc>(s#B   stroke weight (#= -7 to 7 for BOLD style)
<esc>(s0P   proportional spacing OFF
<esc>(s1P   proportional spacing ON
<esc>(s0S   italic OFF
<esc>(s1S   italic ON
<esc>&d@    underlining OFF
<esc>&dD    underlining ON

*****************************************************************************/
