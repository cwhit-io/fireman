
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/**
 *  Main class for the Print Stream Generator program, PSG.java
 *  It includes the main method used to invoke the application
 *  from the console.
 *
 *  Checks input parameters, sets defaults and calls the corresponding
 *  classes that implement IStream interface such as
 *  PSStream, PCLStream and MetaCodeStream
 *
 *  Input:  Text file containing sets of text address lines.
 *          Each set of addreses is separated by a blank line
 *          Input lines may include a 65-character 4-state encoded string
 *
 *  Output: Text file copying the input text lines and adds the
 *          rendered bar-code using a specified font
 *          The file is formatted for printing using a selected PDL
 *          as implied by the form name.
 *
 * Parameters: Two parameters are used.
 *          -font fontName  defaults to     uc23pp
 *          -if   inputFileName defaults to input.txt
 *
 * Java Package Name: Given that several classes are used for this utility,
 *          use of a Java package name is recommended and may later be used
 *          once the name of the USPS library/project is finalized.
 *
 * @author     The Powell Group, TPG
 * @created    March 8, 2006
 */

class PSG  {

    private static Map RecordMap() {
        Map M = new HashMap();
        M.put( "text",    new ArrayList() );
        M.put( "track",   "" );
        M.put( "route",   "" );
        M.put( "barCode", "" );
        return M;
    }

    private static int State( Map M, String r ) {
        int state = 0;
        Matcher m = null;
        Pattern track = Pattern.compile( "^(\\d{20})(\\d{11})");
        Pattern tandr = Pattern.compile( "^(\\d{20})\\s+-\\s+(\\d{11})");
        Pattern bar   = Pattern.compile( "^([ADFT]{65}).*" );
        Pattern route = Pattern.compile( ".*(\\d{5})-(\\d{4}).*" );

        m = track.matcher( r );
        if( m.find() ) { M.put( "track", m.group(1) );M.put( "route", m.group(2) );state = 5;}
        m = tandr.matcher( r );
        if( state==0 && m.find() ) {
            M.put( "track", m.group(1) );M.put( "route",m.group(2) );
            state = 2;
        }
        m = bar.matcher( r );
        if( state==0 && m.find() ) { M.put( "barCode",m.group(1) ); state = 1; }

        m = route.matcher( r );
        if( M.get( "route" ).toString().length()<5 && m.find() ) {
            M.put( "route",m.group(1)+m.group(2) ); state = 4;
        }

        state = r.matches("^\\s*$") ? 9 : state;
        /*********************************************************
        state = r.matches(".*\\d{11}.*")               ? 3 : state;
        state = r.matches("^[ADFT]{65}.*" )            ? 1 : state;
        state = r.matches("^\\d{20}\\s+-\\s+\\d{11}")  ? 2 : state;
        state = r.matches(".*(\\d{5})-(\\d{4}).*")     ? 4 : state;
        **********************************************************/

        if( state < 8 ) ((List)M.get("text")).add( r );
        return state;
    }

    private static void zRead(IStream st, String fileName) {
        String s1;
        try {
            File ifile = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(ifile));
            int state=0;
            Map M = RecordMap();
            for (String in = br.readLine(); in != null; in = br.readLine()) {
                state = State( M,in );
                if( state == 9 ) {
                    st.write( M );
                    M = RecordMap();
                }
            }
            st.write( M );
        } catch (Exception e) { System.out.println(e.toString()); }
    }

    private static void zPrint( Map M ) {
        String k;
        for( Iterator m = M.keySet().iterator(); m.hasNext(); ) {
            k = m.next().toString();
            System.out.println( "\t" + k + ":\t" + M.get( k ).toString() );
        }
    }

    private static void zFiles( Map M ) {
        Map F = new TreeMap();
        F.put("ps","postscript");F.put("pcl","hp");F.put("mc","metacode");
        String font    = M.get( "-fn" ).toString().toLowerCase();
        String dir     = System.getProperty("user.dir");
        String sep     = File.separator, dot=".";
        String file    = M.get( "-if" ).toString(), ofile = "outputFile";
        String suffix  = "txt";
        String pdl     = "", fn="";
        pdl = font.matches("(u[cfs][2][03][h]).*") ? "pcl" :
              font.matches("(u[cfs][2][03][p]).*") ? "ps" : "mc";
        M.put( "-pdl", pdl );
        StringBuffer sb = new StringBuffer( F.get(pdl).toString() + sep   );
        sb.append( M.get( "-font" ).toString().toUpperCase() ).append(".FNT");
        M.put( "-font", findLibrary( "fonts",sb.toString()) );  //font file path
        fn = file;
        fn = fn.indexOf( sep ) >-1 ? fn : dir + sep + file.toString();
        M.put( "-if", fn );
        Pattern pfile  = Pattern.compile( "(.*)(\\..*)$" );
        Matcher m = pfile.matcher( fn );
        ofile = m.find() ? m.group(1) : ofile;
        ofile = ofile.indexOf( sep ) > -1 ? ofile : dir + sep + ofile;
        M.put( "-of",ofile + "-" + font.toUpperCase() + dot + pdl );
    }

    //  searches for fileName in current directory ../path and ./path
    private static String findLibrary( String path, String fileName ) {
        String sep = File.separator;
        String dir = System.getProperty("user.dir");
        File Fd    = new File( dir );
        File Fl    = new File( dir + sep + fileName );
        if( Fl.isFile() ) return Fl.getPath();
        Fl = new File( Fd.getParent() + sep + path + sep + fileName );
        if( Fl.isFile() ) return Fl.getPath();
        Fl = new File( dir + sep + path + sep + fileName );
        if( Fl.isFile() ) return Fl.getPath();
        return "";
    }

    private static void zParms( Map P ) {
        String fi,res,cpi,pdl, fontn, font = P.get( "-font" ).toString().toLowerCase();
        font  = font.matches( "(u[cfs][2][03][hmp][plij]).*" ) ? font : "uc23pp";
        font  = font.matches( "(u[cfs][2][03][h]).*" ) ?
                font.matches( "(u[cfs][2][03][h][pl]).*" ) ? font : "us23hp" : font ;
        P.put("-fn", font.toUpperCase());   // fontName without the extension
        P.put("-font", font);       // font's full path resolved by zFiles
        zFiles( P );                // set paths for input and font files
    }

    private static int zInit( Map M, String[] p) {
        M.put("-font","uc23pp");
        M.put("-if","input.txt");
        int r = 0;
        boolean help = false;
        String hs = "\nUsage: java  -jar  fivp.jar \n";
        String k = "";
        for( int i=0;i<p.length;i+=2 ) {
            k = ( M.containsKey( p[i].toLowerCase() ) && p.length > i ) ?
                                                    p[i].toLowerCase() : "";
            if( M.containsKey( k ) ) M.put( k,p[i+1] );
            if( p[i].toLowerCase().equals("-h") ) help = true;
        }
        if( help || r < 0 ) { System.out.println( hs ); r = -1; }
        return r;
    }

    public static void run( String[] args ) {
        Map P = new TreeMap();
        if ( zInit( P,args) != 0 ) return;
        zParms( P );        // check input parameters input anf font files
        File fi   = new File( P.get( "-if" ).toString() );
        File font = new File( P.get( "-font" ).toString() );
        try {
            if( !fi.exists() || !font.exists() )  {
                System.out.println( "\nCheck availability of input and/or font files\n");
                System.out.println( "\nFile: input:\t" + fi.getPath() );
                System.out.println( "\nFile: font:\t"  + font.getPath() );
                return;
            }

            System.out.println("\nPSG Parameters:\n"); zPrint( P );

            IStream st = null;
            String pdl = P.get( "-pdl" ).toString();
            if( pdl.equals("ps")  ) st = new PSStream( P );
            if( pdl.equals("pcl") ) st = new PclStream( P );
            if( pdl.equals("mc")  ) st = new MetaCodeStream( P );
            zRead( st,P.get( "-if" ).toString() );
            st.newPage().close();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void main(String[] args) {
        run( args );
    }

}
