import java.io.*;
import java.util.*;

/**
 * @author     The Powell Group, TPG
 * @created    March 8, 2006
 *
 * Utility class to recursively scan a directory and return the list
 * of files found
 *.
 */
public final class FileList {
    /**
     * Demonstrate use.
     *
     * @param  ar                         File or Directory
     * @exception  FileNotFoundException  FileNotFoundException
     */
     public static void main(String[] ar) throws FileNotFoundException {
        File tempDir = new File(ar[0]);
        List files = FileList.getFileListing(tempDir);
        //print out all file names, and display the order of File.compareTo
        Iterator filesIter = files.iterator();
        while (filesIter.hasNext()) {
            System.out.println(filesIter.next());
        }
     }

    /**
     * Recursively walk a directory tree and return a List of all
     * Files found; the List is sorted using File.compareTo.
     *
     * @param  aStartingDir               is a valid directory, which can be read.
     * @return                            The fileListing value
     * @exception  FileNotFoundException  Description of the Exception
     */
     public static List getFileListing(File aStartingDir)
                                       throws FileNotFoundException {
        List result = new ArrayList();
        if (!validateDirectory(aStartingDir)) {
            if (aStartingDir.isFile()) {
                result.add(aStartingDir.getPath());
            }
            return result;
        }

        File[] filesAndDirs = aStartingDir.listFiles();
        List filesDirs = Arrays.asList(filesAndDirs);
        Iterator filesIter = filesDirs.iterator();
        File file = null;
        List deeperList = null;

        while (filesIter.hasNext()) {
            file = (File) filesIter.next();
            if (file.isFile() && !file.getName().startsWith(".")) {
                result.add(file.getPath());
            }
            if (!file.isFile() && !file.getName().startsWith(".")) {
                deeperList = getFileListing(file);
                // call recursevely for directory
                result.addAll(deeperList);
            }
        }

        Collections.sort(result);
        return result;
    }

    /**
     * Directory is valid if it exists, is not a file, and can be read.
     *
     * @param  dir                        File or Directory
     * @return                            true: valid directory
     * @exception  FileNotFoundException  FileNotFoundException
     */
     private static boolean validateDirectory(File dir)
             throws FileNotFoundException {
        boolean r = true;
        if (dir == null)        { r = false; }
        if (!dir.exists())      { r = false; }
        //throw new FileNotFoundException("Directory does not exist: " + aDirectory);
        if (!dir.isDirectory()) { r = false; }
        //throw new IllegalArgumentException("Is not a directory: " + aDirectory);
        if (!dir.canRead())     { r = false; }
        //throw new IllegalArgumentException("Directory cannot be read: " + aDirectory);
        return r;
    }
}

