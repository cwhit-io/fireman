import java.io.*;
import java.util.*;
import java.text.*;
import java.util.regex.*;

public class PSStream  extends AStream implements IStream  {
    private FileOutputStream out = null;
    private InputStream       in = null;
    boolean             bfontSet = false;
    private                Map P = null;
    private             int x=72, y=720;

    public PSStream( Map M ) {
        super();
        this.P = M;
    }

    public IStream close() {
        try { this.out.flush(); this.out.close(); }
        catch ( Exception e ) { e.printStackTrace(); }
        return this;
    }

    public void write( Map M ) {
        List X = (List) M.get( "text" );
        for( int i=0; i< X.size(); i++ ) this.addText( X.get(i).toString() );
        //this.addBar( M.get( "barCode" ).toString() );
        this.addBar( super.getBarCode( M ) );
        this.add( "/Courier findfont 11 scalefont setfont\n\r" );
    }

    public IStream addText( String str ) {
        if( !bfontSet ) this.init();
        if( this.y < 165 ) { this.y = 720; this.addText( "showpage" ); }
        this.add( this.x + " " + this.y + " moveto ( " + str + " ) show\n\r" );
        this.y -= 15;
        return this;
    }

    public IStream addBar( String str ) {
        String fn = this.P.get( "-fn" ).toString();
        String scale = fn.matches(".*[fF].*") ? "14.4" : "9.12";
        this.add( "gsave\n\r" );
        this.add( "/" + fn + " findfont "     + scale + " scalefont setfont\n\r" );
        this.add( ""  + x  + " " + (this.y-5) + " moveto ( " + str + " ) show \n\n\r" );
        this.add( "grestore\n\r" );
        y -= ( 40 + 15 );
        return this;
    }

    public IStream add(String str) {
        byte buff[] = new byte[str.length()];
        for (int i=0, l=str.length(); i < l; i++) buff[i] = (byte)str.charAt(i);
        try { out.write(buff); }
        catch (Exception e) {
            e.printStackTrace();e.printStackTrace(System.out);
        }
        return this;
    }

    public IStream newPage() { add( "showpage" ); return this; }

    private void init() {
        try {
            out = new FileOutputStream( new File( P.get( "-of" ).toString() ) );
            in  = new FileInputStream(  new File( P.get( "-font" ).toString() ) );
            byte[] buf = new byte[2048];
            int i = 0;
            while((i=in.read(buf))!=-1) this.out.write(buf, 0, i);
            this.bfontSet = true;
            this.add( "/Courier findfont 11 scalefont setfont\n\r" );
            this.add( "newpath\n\r" );
            //StringBuffer sb = new StringBuffer( super.todayFormated("yyyy.MMM.dd@HH:mm:ss") );
            //sb.append( " " ).append( this.P.get( "-fn" ).toString() );
            //this.addText( sb.toString() );
            //this.addText( " " );
        } catch (Exception e) { e.printStackTrace(); }
    }

}

