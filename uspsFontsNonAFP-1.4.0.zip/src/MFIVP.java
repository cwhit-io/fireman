import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 *  Utility class to call FIVP with all names found in the /fonts
 *  directory
 *
 *  This utility function will be implemented as "-all 1" optional
 *  parameter in FIVP; for now it is a separete class to automate
 *  the production of print-ready files for fonts in /fonts
 *
 *  @author     The Powell Group, TPG
 *  @created    March 8, 2006
 */
public final class MFIVP {
    /**
     *  Utility class to call FIVP with all names found in the /fonts
     *  directory
     *
     *  This utility function will be implemented as "-all 1" optional
     *  parameter in FIVP; for now it is a separete class to automate
     *  the production of print-ready files for fonts in /fonts
     *
     * @param  ar                         direcetoryName defaults to ./fonts
     * @exception  FileNotFoundException  File not found
     */
    public static void main(String[] ar) throws FileNotFoundException {
        String dir = ar.length > 0 ? ar[0] : "./fonts";
        File fd = new File( dir );
        List F = FileList.getFileListing(fd);

        Iterator filesIter = F.iterator();
        String sep = File.separator;
        String s1 = null;
        String s2 = null;
        int i = 0;
        String[] sa = new String[2];
        sa[0] = "-font";
        while (filesIter.hasNext()) {
            s1 = filesIter.next().toString();
            i = s1.lastIndexOf( sep.charAt(0) );
            s2 = i>0 ? s1.substring(i+1) : "notFound";
            i = s2.lastIndexOf( "." );
            s2 = i>0 ? s2.substring(0,i) : s2;
            sa[1] = s2;
            FIVP.run(sa);
        }
    }
}

