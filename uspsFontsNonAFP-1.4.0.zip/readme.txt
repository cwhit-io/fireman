
USPS Intelligent Mail COMPACT barcode fonts

    This package contains the distribution for Adobe Postscript, 
    HP PCL, Xerox Metacode and TrueType Compact and Regular   
    fonts developed for the USPS Intelligent Mail barcode.

Directory Structure

    The zip-file content is as follows:
    
    readme.txt  This file. It provides summary information for the 
                zip-file distribution.
   
    /docs       Contains product documentation

        uspsFontsNonAFP-1.4.0.pdf    font user's guide in PDF

    /fonts      USPS Intelligent Mail barcode Compact and Standard fonts  
                for Adobe Postscript Type3, HP PCL, Xerox Metacode

        /scalable
            /trueType           TrueType Compact and Standard fonts and browser test HTML file
            /postscriptType1    Postscript Type1 font and metric files

    /prfiles    Print-ready files suitable to be directed to a printer
                to validate rendering of fonts included in /fonts

    /src        Java source code used to produce the print-ready files
                in /prfiles for the fonts /fonts

    /bin        Contains the java executable file for the PSG.java utility
                used to produce print-ready files

        psg.jar         Java executable for PSG.java used to generate
                        the print-ready files.
        readme.txt      Describes the operation of the PSG.java sample
                        program
        input.txt       Text file used for input for PSG.java to generate
                        print-ready files
                        
    /lib        Libraries used by Java to call the USPS Encoder under MS Win32
                and under Linux Intel/AMD-32-bit

    /data       Sample text input files used to produce print-ready files


    
Font Naming Convention 

    Fonts included in directory /fonts have a naming convention as follows:
              
    UhccPo.FNT
       
        U - USPS Intelligent Mail barcode font

        h - height -        "S" - standard height, 
                            "C" - compact height

        cc - cpi -           23   characters per inch

        P - PDL font family "P" - PostScript
                            "H" - HP's PCL
                            "M" - Xerox Metacode

        o - orientation -   "P" - portrait
                            "L" - landscape
                            "I" - inverse portrait
                            "J" - inverse landscape   
                            "1" - Postscript Type 1 Scalable   
                            
    Example:  UC23PP.FNT
              ... ..
              ... .P.........Portrait Orientation
              ... P..........PostScript Print Description Language
              ..23...........23 Characters per Inch - CPI
              .C.............Compact height
              U..............USPS Intelligent Mail barcode font

    The "scalable" fonts, postscript type1 and truetype, are named:

	      USPSIMBCompact and USPSIMBStandard
              


